from django.contrib import admin
from.models import Tutorial,Question,QuestionCategory,QuestionSeries,ImageBase,Page,Result,Exame
from tinymce.widgets import TinyMCE
from django.db import models
class TutorialAdmin(admin.ModelAdmin):

    fieldsets = [
        ("Title/date", {'fields': ["tutorial_title", "tutorial_published"]}),
        ("Content", {"fields": ["tutorial_content"]})
    ]

    formfield_overrides = {
        models.TextField: {'widget': TinyMCE()},
        }


admin.site.register(Tutorial,TutorialAdmin)
class QuestionAdmin(admin.ModelAdmin):
        formfield_overrides = {
        models.TextField: {'widget': TinyMCE()},
        }

admin.site.register(Question,QuestionAdmin)
# Register your models here.

class PageAdmin(admin.ModelAdmin):
        formfield_overrides = {
        models.TextField: {'widget': TinyMCE()},
        }

admin.site.register(Page,PageAdmin)

admin.site.register(QuestionCategory)
admin.site.register(QuestionSeries)
admin.site.register(ImageBase)
admin.site.register(Result)
admin.site.register(Exame)
