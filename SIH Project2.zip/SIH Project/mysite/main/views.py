from django.shortcuts import render, redirect
from .models import Tutorial,Question,QuestionSeries,QuestionCategory,Exame,Result
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import logout, authenticate, login
from django.contrib import messages
from .forms import NewUserForm
from django.http import HttpResponse
import random
from.models import Page
from django.core.mail import send_mail
from django.conf import settings
import pygal
from datetime import datetime
# Create your views here.

def push_result(name,exame,m,c,w,s):
    result=Result(user_name=name,exame_name=exame,total_marks=m,
                  correct=c,wrong=w,skip=s)
    result.save()

def single_slug(request, single_slug):
    categories = [c.category_slug for c in QuestionCategory.objects.all()]
    if single_slug in categories:
        matching_series = QuestionSeries.objects.filter(question_category__category_slug=single_slug)
        return render(request=request,
                      template_name='main/category.html',
                      context={"question_series": matching_series})
    serise=[ i.question_series for i in QuestionSeries.objects.all() ]
    if single_slug in serise:
        obj=Exame.objects.get(pk=1)
        num=obj.number_of_question
        time=obj.time_of_test
        data=random.sample(list(Question.objects.filter(question_series__question_series=single_slug)),k=num)
        if not request.user.is_authenticated:
            messages.error(request, "Frist you have to Login !")
            return redirect("main:login")
        return render(request,'main/quiz.html',{"question":data,"total_time":time})
    return HttpResponse("'Not available'")

def test(request):
    return render(request,'main/test.html',{'categories':QuestionCategory.objects.all()})

def about(request):

    return render(request = request,
                  template_name='main/about.html',
                  context = {"data":Page.objects.get(pk=2)}) 

def homepage(request):
#    subject = 'Thank you for registering to our site'
 #   message = ' it  means a world to us '
  #  email_from = settings.EMAIL_HOST_USER
   # recipient_list = ['justnavneet89@gmail.com',]
   # send_mail( subject, message, email_from, recipient_list )
    return render(request = request,
                  template_name='main/home.html',
                  context = {"data":Page.objects.get(pk=1)}) 

def register(request):
    if request.method == "POST":
        form = NewUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f"New account created: {username}")
            messages.success(request, f"{username} goto your emali and get password")
            #data= form.cleaned_data.get('email')
            
            login(request, user)
            return redirect("main:homepage")
        else:
            for msg in form.error_messages:
                messages.error(request, f"{msg}: {form.error_messages[msg]}")

            return render(request = request,
                          template_name = "main/register.html",
                          context={"form":form})

    form = NewUserForm
    return render(request = request,
                  template_name = "main/register.html",
                  context={"form":form})

def logout_request(request):
  logout(request)
  messages.info(request, "Logged out successfully!")
  return redirect("main:homepage")

def login_request(request):
    if request.method == 'POST':
        form = AuthenticationForm(request=request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.info(request, f"You are now logged in as {username}")
                return redirect('/')
            else:
                messages.error(request, "Invalid username or password.")
        else:
            messages.error(request, "Invalid username or password.")
    form = AuthenticationForm()
    return render(request = request,
                    template_name = "main/login.html",
                    context={"form":form})

def quiz(request):
    obj=Exame.objects.get(pk=1)
    num=obj.number_of_question
    time=obj.time_of_test
    data=random.sample(list(Question.objects.all()),k=num)
    return render(request,'main/quiz.html',{"question":data,"total_time":time})

def result(request):
    obj=[]
    k=Exame.objects.get(pk=1)
    c,w=k.marks_for_correct,k.marks_for_wrong
    correct=wrong=skip=marks=0
    size=k.number_of_question+1
    for i in range(1,size):
        temp=request.POST.get(str(i)).split('_')
        id=temp[1]
        op=temp[0]
        j=Question.objects.get(pk=id)
        data={'body':j.question_body,
        '1':j.option_1,
        '2':j.option_2,
        '3':j.option_3,
        '4':j.option_4,
        '5':'Not given'}
        na=str(j.answer)       
        obj.append( [ data['body'] ,
                    'correct answer is '+data[na] , 
                    'your answer is '+data[op] ]  )
        if (data[op]  == data[na] ):
            marks=marks+c
            correct=correct+1
        elif(data[op]==data['5']):
            marks=marks+0
            skip=skip+1
        else:
            marks=marks+w
            wrong=wrong+1
        exame=j.question_series
    push_result(request.user,exame,marks,correct,wrong,skip)
    data={"result":obj ,"marks":marks,"w":wrong,"c":correct,"s":skip,"ex":exame}

    return render(request,'main/result.html',data)

def account(request):
    if not request.user.is_authenticated:
        messages.error(request, "Frist you have to Login !")
        return redirect("main:login")
    c=[]
    w=[]
    s=[]
    t=[]
    date=[]
    data=Result.objects.filter(user_name=request.user)
    for i in data:
        c.append(i.correct)
        date.append(i.exame_name+' | '+i.exame_date.strftime("%m/%d/%Y | %I:%M:%S %p"))
        w.append(i.wrong)
        s.append(i.skip)
        t.append(i.total_marks)
    line_chart = pygal.HorizontalBar()
    line_chart.title = 'Track Record'
    line_chart.x_labels = date
    line_chart.add('correct answer',c)
    line_chart.add('wrong answer',w)
    line_chart.add('skiped answer',s)
    line_chart.add('Total marks',t)
    graph_data = line_chart.render_data_uri()
    return render(request,'main/account.html',{'graph_data': graph_data})