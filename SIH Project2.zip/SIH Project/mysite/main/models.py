from django.db import models
from datetime import datetime
# Create your models here.
class Tutorial(models.Model):
    tutorial_title = models.CharField(max_length=200)
    tutorial_content = models.TextField()
    tutorial_published = models.DateTimeField('date published',default=datetime.now())

    def __str__(self):
        return self.tutorial_title

class ImageBase(models.Model):
    image_title=models.CharField(max_length=200)
    image=models.ImageField(upload_to='main/image')
    def __str__(self):
        return self.image_title

class Page(models.Model):
    page_title=models.CharField(max_length=200)
    page_body=models.TextField()
    def __str__(self):
        return self.page_title

class QuestionCategory(models.Model):

    question_category = models.CharField(max_length=200)
    category_summary = models.CharField(max_length=200)
    category_slug = models.CharField(max_length=200)

    class Meta:
        # Gives the proper plural name for admin
        verbose_name_plural = "Categories"
    def __str__(self):
        return self.question_category

class QuestionSeries(models.Model):
    question_series = models.CharField(max_length=200)

    question_category = models.ForeignKey(QuestionCategory, verbose_name="Category",on_delete=models.SET_DEFAULT,default=1)
    series_summary = models.CharField(max_length=200)
    #serise_url=models.CharField(max_length=200)
    class Meta:
        # otherwise we get "question Seriess in admin"
        verbose_name_plural = "Series"

    def __str__(self):
        return self.question_series

class Question(models.Model):
    question_body=models.TextField()

    option_1=models.CharField(max_length=200,default='a')
    option_2=models.CharField(max_length=200,default='b')
    option_3=models.CharField(max_length=200,default='c')
    option_4=models.CharField(max_length=200,default='d')
    answer=models.IntegerField()
    question_series = models.ForeignKey(QuestionSeries, default=1, verbose_name="Series", on_delete=models.SET_DEFAULT)
    #tutorial_slug = models.CharField(max_length=200, default=1)
    image=models.ImageField(upload_to='main/image',default="1")
    def __str__(self):
        return( str(self.question_series)+ ' ' + str(self.id))
 
class Result(models.Model):
    user_name=models.CharField(max_length=200)
    exame_name=models.CharField(max_length=200)
    exame_date=models.DateTimeField('exame date',default=datetime.now())
    total_marks=models.IntegerField()
    correct=models.IntegerField()
    wrong=models.IntegerField()
    skip=models.IntegerField()
    def __str__(self):
        return( str(self.user_name)+ ' ' + str(self.exame_name))

class Exame(models.Model):
    time_of_test=models.CharField(max_length=10)
    number_of_question=models.IntegerField()
    marks_for_correct=models.IntegerField()
    marks_for_wrong=models.IntegerField()




